for ((N=100;N<50001;N+=100))
do
    ./SumaVectores $N
done
